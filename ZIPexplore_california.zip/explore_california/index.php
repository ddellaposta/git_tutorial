<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Welcome to Explore California</title>
    <link href="assets/stylesheets/main.css" rel="stylesheet" type="text/css" media="all">
    <script src="assets/javascripts/jquery-1.5.1.min.js"></script>
    <script src="assets/javascripts/jquery-ui-1.8.10.custom.min.js"></script>
    <script src="assets/javascripts/menus.js"></script>
  </head>
  <body id="home">
    <div id="wrapper">

        <?php include('nav.php'); ?>

      <div id="actionCall">
        <h1>NSSA 713 Lab 3</h1>
        <a href="tours.html" title="Find your tour!"><h2>Find your tour</h2></a>
      </div>

      <div id="contentWrapper">
        <div id="mainContent">
          <div id="mainArticle"> 
            <h1>Tour Spotlight</h1>
            <p class="spotlight">This month's spotlight package is Cycle California. Whether you are looking for some serious downhill thrills to a relaxing ride along the coast, you'll find something to love in Cycle California.<br /> <span class="accent"><a href="tours_cycle.html" title="Cycle California">tour details</a></span></p>
            
            <h1>Explorer's Podcast</h1>
            <p class="videoText">Join us each month as we publish a new Explore California video podcast, with featured tours, customer photos, and some exciting new features!<span class="accent"><a href="explorers/video.html" title="Video Podcast">Watch the full video</a></span></p>
          </div>
        </div>
        
        <div id="secondaryContent">
          <div id="specials" class="callOut">
            <h1>Monthly Specials</h1>
            <h2 class="top"><img src="assets/images/calm_bug.gif" alt="California Calm" width="75" height="75" />California Calm</h2>
            <p>Day Spa Package <br />
              <a href="tours/tour_detail_cycle.html">$250</a></p>
            <h2><img src="assets/images/desert_bug.gif" alt="From desert to sea" width="75" height="75" />From Desert to Sea</h2>
            <p>2 Day Salton Sea <br />
              <a href="tours/tour_detail_cycle.html">$350</a></p>
            <h2><img src="assets/images/backpack_bug.gif" alt="Backpack Cal" width="75" height="41" />Backpack Cal</h2>
            <p>Big Sur Retreat <br />
              <a href="tours/tour_detail_cycle.html">$620</a></p>
            <h2><img src="assets/images/taste_bug.gif" alt="Taste of California" width="75" height="75" />Taste of California</h2>
            <p>Tapas &amp; Groves <br />
              <a href="tours/tour_detail_taste.html">$150</a></p>
          </div>
        
          <div id="trivia" class="callOut">
            <h1>Did You Know?</h1>
            <p>The official state flag of California was designed by William Todd and first used on June 14, 1846. The flag was not officially adopted until 1911. The flag features a grizzly bear, a red bar, a star and is one of the most recognizable state flags in the Nation.</p>
          </div>
        </div>
      </div>
  
      <div id="pageFooter">
        <div id="quickLinks">
          <h1>Quick Nav</h1>
          <ul id="quickNav">
            <li><a href="index.html" title="Our home page">Home</a></li>
            <li><a href="tours.html" title="Explore our tours">Tours</a></li>
            <li><a href="mission.html" title="What we think">Mission</a></li>
            <li><a href="resources.html" title="Guidance and planning">Resources</a></li>
            <li><a href="explorers.html" title="Join our community">Explorers</a></li>
            <li><a href="contact.html" title="Contact and support">Contact</a></li>
          </ul>
        </div>
        <div id="footerResources">
          <h1>Resources</h1>
          <ul id="quickNav">
            <li><a href="resources/faq.html" title="Our home page">FAQ</a></li>
            <li><a href="support.html" title="Need help?">Support</a></li>
            <li><a href="resources/legal.html" title="The fine print">Legal</a></li>
          </ul>
        </div>
        <div id="companyInfo">
          <h1>Contact</h1>
          <h2>Explore California</h2>
          <p>5605 Nota Street<br />
            Ventura, CA 93003</p>
          <p>866.555.4310<br />866.555.4315 <em>(24 hour support)</em></p>
        </div>
      </div>
    </div>
  </body>
</html>
