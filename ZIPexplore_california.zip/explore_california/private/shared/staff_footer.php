<footer>
  &copy; <?php echo date('Y'); ?> Explore California
</footer>

</body>
</html>

<?php
  db_disconnect($db);
?>
