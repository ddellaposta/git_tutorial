<?php

define("DB_SERVER", "localhost");
define("DB_USER", "dbuser");
define("DB_PASS", "password");
define("DB_NAME", "globe_bank");

?>
