<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Explore California: Mission</title>
    <link href="assets/stylesheets/main.css" rel="stylesheet" type="text/css" media="all">
    <script src="assets/javascripts/jquery-1.5.1.min.js"></script>
    <script src="assets/javascripts/jquery-ui-1.8.10.custom.min.js"></script>
    <script src="assets/javascripts/menus.js"></script>
  </head>
  <body>
    <div id="wrapper">

      <?php include('nav.php'); ?>

      <div id="mainContent">
        <div id="contentHeader">
          <h1>Our Mission</h1>
        </div>
        <div id="mainArticle">
          <h1>Who we are</h1>
          <img src="assets/images/mission_look.jpg" alt="Looking out at the Pacific" class="articleImage" />
          <div class="multiCol">
            <p>We are passionate about California and preserving the abundant resources that make it so unique. Our goal at Explore California is to transform your vacation into an adventure that will educate, inspire, and energize you unlike any other.</p> 
            <p>Our tours are crafted around our central mission, and are designed to engage you in a unique and fulfilling way. All our tours are sensitive to the environment, and will provide you will an opportunity to explore California in your own way.</p>
            <p>We've been asked before how we choose our tours. It's simple really, we approach our tours as the enthusiasts we are! When we scout for locations, choose tour options, or explore the surrounding area for exciting side-tours, we ask ourselves one question, &quot;is this something we would want to do?&quot; We also look very carefully at a tour's potential impact. We choose tours that are as environmentally sensitive as we are, and that expose people to amazing diversity of California's people, places, and wildlife!</p>
            <p>We've also worked very hard to make Explore California more than just a tour company. <a href="explorers/join.html">Join our community</a> and become part of the conversation. Recommend tours, blog about your journeys, and share pictures and video with other tour members.</p>
          </div>
        </div>
      </div>
      
      <div id="secondaryContent">
        <div id="specials" class="callOut">
          <h1>Monthly Specials</h1>
          <h2 class="top"><img src="assets/images/calm_bug.gif" alt="California Calm" width="75" height="75" />California Calm</h2>
          <p>Day Spa Package <br />
            <a href="tours/tour_detail_cycle.html">$250</a></p>
          <h2><img src="assets/images/desert_bug.gif" alt="From desert to sea" width="75" height="75" />From Desert to Sea</h2>
          <p>2 Day Salton Sea <br />
            <a href="tours/tour_detail_cycle.html">$350</a></p>
          <h2><img src="assets/images/backpack_bug.gif" alt="Backpack Cal" width="75" height="41" />Backpack Cal</h2>
          <p>Big Sur Retreat <br />
            <a href="tours/tour_detail_cycle.html">$620</a></p>
          <h2><img src="assets/images/taste_bug.gif" alt="Taste of California" width="75" height="75" />Taste of California</h2>
          <p>Tapas &amp; Groves <br />
            <a href="tours/tour_detail_taste.html">$150</a></p>
        </div>
        <div id="trivia" class="callOut">
          <h1>Did You Know?</h1>
          <p>California produces over 17 million gallons of wine each year!</p>
        </div>
      </div>
      
      <div id="pageFooter">
        <div id="quickLinks">
          <h1>Quick Nav</h1>
          <ul id="quickNav">
            <li><a href="index.html" title="Our home page">Home</a></li>
            <li><a href="tours.html" title="Explore our tours">Tours</a></li>
            <li><a href="mission.html" title="What we think">Mission</a></li>
            <li><a href="resources.html" title="Guidance and planning">Resources</a></li>
            <li><a href="explorers.html" title="Join our community">Explorers</a></li>
            <li><a href="contact.html" title="Contact and support">Contact</a></li>
          </ul>
        </div>
        <div id="footerResources">
          <h1>Resources</h1>
          <ul id="quickNav">
            <li><a href="resources/faq.html" title="Our home page">FAQ</a></li>
            <li><a href="support.html" title="Need help?">Support</a></li>
            <li><a href="resources/legal.html" title="The fine print">Legal</a></li>
          </ul>
        </div>
        <div id="companyInfo">
          <h1>Contact</h1>
          <h2>Explore California</h2>
          <p>5605 Nota Street<br />
            Ventura, CA 93003</p>
          <p>866.555.4310<br />866.555.4315 <em>(24 hour support)</em></p>
        </div>
      </div>
    </div>
  </body>
</html>
