<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Explore California: Tours - Backpack Cal</title>
    <link href="../assets/stylesheets/main.css" rel="stylesheet" type="text/css" media="all">
    <script src="../assets/javascripts/jquery-1.5.1.min.js"></script>
    <script src="../assets/javascripts/jquery-ui-1.8.10.custom.min.js"></script>
    <script src="../assets/javascripts/menus.js"></script>
  </head>
  <body>
    <div id="wrapper">

	<?php include('nav.php'); ?>
  
      <div id="mainContent">
        <div id="contentHeader" class="hasCrumbs">
          <h1>Our Tours</h1>
          <div id="subLinks">
            <p><a href="../tours.html" title="Browse tours">All Tours</a> &raquo; <a href="tour_detail_backpack.html" title="Browse tours">  Backpack Cal</a></p>
          </div>
        </div>
 
        <div id="mainArticle">
          <h1>Backpack Cal</h1>
          <img src="../assets/images/backpack_main.jpg" alt="Backpack Cal" class="articleImage" />
          <div class="multiCol">
            <p>Want a chance to get away from it all? Do you prefer to see nature at your own pace? Respond to the call of the great outdoors with our Backpack Cal tour packages. Whether it's hiking beneath the towering Redwoods, walking the ridges of the beautiful Channel Islands, or testing yourself against the harshest environments nature has to offer, we have a tour for your abilities and interests. </p>
            <p>If you're looking to just take in the incredible natural beauty of California at your own pace, try our Big Sur Retreat, a stress-free retreat into one of America's most beautiful forest regions. If you have the spirit of an adventurer and are looking for a challenge, try our Death Valley Survivor's Trek, an aptly-named tour that will test your endurance and mental strength as you pit yourself against the harshest desert conditions in the country. </p>
            <p>Our Backpack Cal Tours offer a range of physical activity, from easy to difficult. Please check the difficulty rating before booking a tour to ensure that your experience is the best possible for your current fitness level. Tours with a rating of Moderate or higher require a signed waiver before booking.</p>
          </div>
          
          <div id="tourDescriptions">
            <div class="tourDescription">
              <h2>Big Sur Retreat </h2>
              <h3 class="price">3 days $750</h3>
              <p><img src="../assets/images/map_bigsur.gif" alt="Backpack Cal" width="115" height="130" />Big Sur is big country. The Big Sur Retreat takes you to the most majestic part of the Pacific Coast and show you secret trails and spectacular scenery. This is one of our most flexible tours, with enough options to satisfy the casual hiker to the hard core experience junkie.<br />
              <span class="option">Optional 4 day tour available | Rating: Medium </span></p>
              <p><a href="tour_detail_bigsur.html" title="Big Sur Retreat" class="more">learn more!</a> <a href="../booking.html" title="Book Now!" class="book">book now!</a></p>
            </div>
              
            <div class="tourDescription">
              <h2>Channel Islands Excursion</h2>
              <h3 class="price">1 day $150</h3>
              <p><img src="../assets/images/map_channel.gif" alt="Backpack Cal" width="115" height="130" />The chain known as the Channel Islands offer some of the most diverse and unique landscape on the Pacific coast. No motor vehicles are allowed on the islands, which makes this relaxing day trip hiking package the best and most interesting way to visit.<br />
              <span class="option"> Rating: Easy </span></p>
              <p><a href="tour_detail_bigSur.html" title="Big Sur Retreat" class="more">learn more!</a> <a href="../booking.html" title="Book Now!" class="book">book now!</a></p>
            </div>
             
            <div class="tourDescription">
              <h2>The Death Valley Survivor's Trek</h2>
              <h3 class="price">2 days $250</h3>
              <p><img src="../assets/images/map_valley.gif" alt="Backpack Cal" width="115" height="130" />Hot stuff? Need more of a challenge? Take this tour to the hottest place in North America: Death Valley. Due to extreme temperatures (120 degrees and higher) in the summer months, this tour is only offered November through April. Are you up to the challenge?<br />
              <span class="option">Rating: Difficult</span></p>
              <p><a href="tour_detail_bigSur.html" title="Big Sur Retreat" class="more">learn more!</a> <a href="../booking.html" title="Book Now!" class="book">book now!</a></p>
            </div>
              
            <div class="tourDescription">
              <h2>In the Steps of John Muir </h2>
              <h3 class="price">3 days $600</h3>
              <p><img src="../assets/images/map_yosemite.gif" alt="Backpack Cal" width="115" height="130" />Follow in the steps on John Muir, famous naturalist and founder of the Sierra Club, and walk the same trails he helped blaze in and around Yosemite National Park.<br />
              <span class="option">Rating: Difficult </span></p>
              <p><a href="tour_detail_bigSur.html" title="Big Sur Retreat" class="more">learn more!</a> <a href="../booking.html" title="Book Now!" class="book">book now!</a></p>
            </div>
            
            <div class="tourDescription">
              <h2>The Mt. Whitney Climbers Tour</h2>
              <h3 class="price">4 days $650</h3>
              <p><img src="../assets/images/map_whitney.gif" alt="Backpack Cal" width="115" height="130" />Climb to the sky! The Mt. Whitney Climbers Tour takes you to the top of this 14,000 ft. of mountain in 4 days- our longest and most strenuous backpacking tour. Explore California will set you up with a trail permit, a two night camping pass, and an expert guide.<br />
              <span class="option">Rating: Difficult </span></p>
              <p><a href="tour_detail_bigSur.html" title="Big Sur Retreat" class="more">learn more!</a> <a href="../booking.html" title="Book Now!" class="book">book now!</a></p>
            </div>
            
          </div>
        </div>

      </div>
      
      <div id="secondaryContent">
        <div id="specials" class="callOut">
          <h1>Monthly Specials</h1>
          <h2 class="top"><img src="../assets/images/calm_bug.gif" alt="California Calm" width="75" height="75" />California Calm</h2>
          <p>Day Spa Package <br />
            <a href="../tours/tour_detail_cycle.html">$250</a></p>
          <h2><img src="../assets/images/desert_bug.gif" alt="From desert to sea" width="75" height="75" />From Desert to Sea</h2>
          <p>2 Day Salton Sea <br />
            <a href="../tours/tour_detail_cycle.html">$350</a></p>
          <h2><img src="../assets/images/backpack_bug.gif" alt="Backpack Cal" width="75" height="41" />Backpack Cal</h2>
          <p>Big Sur Retreat <br />
            <a href="../tours/tour_detail_cycle.html">$620</a></p>
          <h2><img src="../assets/images/taste_bug.gif" alt="Taste of California" width="75" height="75" />Taste of California</h2>
          <p>Tapas &amp; Groves <br />
            <a href="../tours/tour_detail_taste.html">$150</a></p>
        </div>
        <div id="trivia" class="callOut">
          <h1>Did You Know?</h1>
          <p>John Muir was Scottish-born, but he loved the American wilderness. Founder of the Sierra Club, he also lobbied for the establishment of national parks, which he succeeded at in 1899 with the passage of the National Parks Bill and the creation of his beloved Yosemite National Park.</p>
        </div>
      </div>
  
      <div id="pageFooter">
        <div id="quickLinks">
          <h1>Quick Nav</h1>
          <ul id="quickNav">
            <li><a href="../index.html" title="Our home page">Home</a></li>
            <li><a href="../tours.html" title="Explore our tours">Tours</a></li>
            <li><a href="../mission.html" title="What we think">Mission</a></li>
            <li><a href="../resources.html" title="Guidance and planning">Resources</a></li>
            <li><a href="../explorers.html" title="Join our community">Explorers</a></li>
            <li><a href="../contact.html" title="Contact and support">Contact</a></li>
          </ul>
        </div>
        <div id="footerResources">
          <h1>Resources</h1>
          <ul id="quickNav">
            <li><a href="../resources/faq.html" title="Our home page">FAQ</a></li>
            <li><a href="../support.html" title="Need help?">Support</a></li>
            <li><a href="../resources/legal.html" title="The fine print">Legal</a></li>
          </ul>
        </div>
        <div id="companyInfo">
          <h1>Contact</h1>
          <h2>Explore California</h2>
          <p>5605 Nota Street<br />
            Ventura, CA 93003</p>
          <p>866.555.4310<br />866.555.4315 <em>(24 hour support)</em></p>
        </div>
      </div>

    </div>
  </body>
</html>
