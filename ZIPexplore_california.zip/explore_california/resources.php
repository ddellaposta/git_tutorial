<!DOCTYPE html PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN"
   "http://www.w3.org/TR/html4/loose.dtd">
<html lang="en">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <title>Explore California: Resources</title>
    <link href="assets/stylesheets/main.css" rel="stylesheet" type="text/css" media="all">
    <script src="assets/javascripts/jquery-1.5.1.min.js"></script>
    <script src="assets/javascripts/jquery-ui-1.8.10.custom.min.js"></script>
    <script src="assets/javascripts/menus.js"></script>
  </head>
  <body>
    <div id="wrapper">

 	<?php include('nav.php'); ?>
  
      <div id="mainContent">
        <div id="contentHeader" class="hasCrumbs">
          <h1>Resources</h1>
          <div id="subLinks">
  		      <ul>
              <li><a href="resources/faq.html" title="Got questions?">Tour FAQs</a></li>
              <li><a href="resources/additional_resources.html" title="additional resources">Tour Information</a></li>
              <li><a href="resources/terms.html" title="terms and conditions">Site Terms</a></li>
            </ul>
          </div>
        </div>
        
        <div id="mainArticle">
          <h1>Need help planning?</h1>
          <img src="assets/images/looking.jpg" alt="Plan your tour" class="articleImage" />
          <div class="multiCol">
            <p>If you have questions about an upcoming trip, you've come to the right place! Here you'll find <a href="resources/faq.html">FAQ</a>'s for each of our tour packages, answers to general tour questions, and some <a href="resources/links.html">tour information</a> that can help you plan your trips. You'll also find our <a href="resources/legal.html">privacy</a> and legal mumbo-jumbo that helps explain the <a href="explorers/join.html">terms</a> of our site, and our tours. If you have any additional questions, feel free to <a href="contact.html">contact</a> us.</p>
            
            <h2>General Tour Information</h2>
   
            <h3>Customer notifications</h3>
            <p>When you book a tour with Explore California, you should receive two notifications via email. The first will be a <strong>tour confirmation</strong>, which states that your tour is booked, gives you the dates of your tour, and lists all amenities included in your package. The second notification should arrive two weeks prior to the start of your tour. This will be a <strong>reminder notification</strong> and will contain your tour dates and current tour conditions, if applicable. <em>If you do not receive a confirmation within 24 hours, or the reminder notification two weeks out, contact us immediately</em>. We’ll make sure there are no problems in the system and confirm your tour.</p>
            
            <h3>Tour vouchers</h3>
            <p>Some tour packages include tour vouchers. These tour vouchers allow you to participate in optional activities during a tour and are usually scheduled for downtime or as an optional choice to replace the day’s featured activity. The vouchers are only good during the tour and have no cash value, and cannot be redeemed if the tour is not taken. The tour vouchers are negotiated with 3rd party vendors. Although Explore California monitors these vendors closely, we cannot guarantee that scheduled activities will take place.</p>
   
            <h3>Trip planning</h3>
            <p>After registration, you will be sent a PDF trip planning document specific to your tour. In the Trip Planner we offer packing advice, places of interest along the tour route, a historical and environmental overview of the tour, a list of any required equipment for the tour that is <em>not</em> provided by Explore California, and additional resources for researching the surrounding area and points of interest included in your tour. Additional information about specific tours can be found in our FAQ section.</p>
          </div>
   
          <h3>Tour checklist</h3>
          <p>As you prepare for your tour, we want to make sure that you have everything you need to fully enjoy your time in California. Having everything in place when you arrive makes it easy to sit back and enjoy all that your tour has to offer. For more information on traveling to California, go to <a href="http://www.visitcalifornia.com" target="_blank">Visit California.com</a>. With that in mind, we’ve prepared a small checklist to help you make sure you’re ready to go!</p>
          <ul>
            <li>Have you arranged for your mail/paper deliver?</li>
            <li>Are friends/family aware of your itinerary?</li>
            <li>Do you have the tickets, vouchers, or trail passes provided by Explore California?</li>
            <li>Have you printed out your tour confirmation?</li>
            <li>Read your confirmation email carefully; is there any required equipment for your tour that is <em>not</em> provided by Explore California?</li>
            <li>Is your trip an outdoor adventure? If so we recommend the following:
              <ul>
                <li>Comfortable hiking shoes</li>
                <li>Hat</li>
                <li>Wet/dry bag to protect valuables</li>
                <li>Comfortable backpack</li>
                <li>Stainless steel water bottle</li>
                <li>Multi-purpose tool</li>
                <li>Pack no more than one additional day of clothing</li>
                <li>Insect repellent</li>
                <li>Sunglasses</li>
                <li>Sunscreen</li>
              </ul>
            </li>
            <li>Bring comfortable shoes. (I know, we shouldn’t have to say that, but you’d be amazed)</li>
            <li>No guitars are allowed in campsites</li>
            <li>No firearms or other weapons are allowed on tours</li>
            <li>Leave expensive jewelry at home</li>
            <li>We recommend packing a small first aid kit</li>
          </ul>
        </div>
      </div>
      
      <div id="secondaryContent">
        <div id="specials" class="callOut">
          <h1>Monthly Specials</h1>
          <h2 class="top"><img src="assets/images/calm_bug.gif" alt="California Calm" width="75" height="75" />California Calm</h2>
          <p>Day Spa Package <br />
            <a href="tours/tour_detail_cycle.html">$250</a></p>
          <h2><img src="assets/images/desert_bug.gif" alt="From desert to sea" width="75" height="75" />From Desert to Sea</h2>
          <p>2 Day Salton Sea <br />
            <a href="tours/tour_detail_cycle.html">$350</a></p>
          <h2><img src="assets/images/backpack_bug.gif" alt="Backpack Cal" width="75" height="41" />Backpack Cal</h2>
          <p>Big Sur Retreat <br />
            <a href="tours/tour_detail_cycle.html">$620</a></p>
          <h2><img src="assets/images/taste_bug.gif" alt="Taste of California" width="75" height="75" />Taste of California</h2>
          <p>Tapas &amp; Groves <br />
            <a href="tours/tour_detail_taste.html">$150</a></p>
        </div>
        <div id="trivia" class="callOut">
          <h1>Did You Know?</h1>
          <p>California produces over 17 million gallons of wine each year!</p>
        </div>
      </div>
      
      <div id="pageFooter">
        <div id="quickLinks">
          <h1>Quick Nav</h1>
          <ul id="quickNav">
            <li><a href="index.html" title="Our home page">Home</a></li>
            <li><a href="tours.html" title="Explore our tours">Tours</a></li>
            <li><a href="mission.html" title="What we think">Mission</a></li>
            <li><a href="resources.html" title="Guidance and planning">Resources</a></li>
            <li><a href="explorers.html" title="Join our community">Explorers</a></li>
            <li><a href="contact.html" title="Contact and support">Contact</a></li>
          </ul>
        </div>
        <div id="footerResources">
          <h1>Resources</h1>
          <ul id="quickNav">
            <li><a href="resources/faq.html" title="Our home page">FAQ</a></li>
            <li><a href="support.html" title="Need help?">Support</a></li>
            <li><a href="resources/legal.html" title="The fine print">Legal</a></li>
          </ul>
        </div>
        <div id="companyInfo">
          <h1>Contact</h1>
          <h2>Explore California</h2>
          <p>5605 Nota Street<br />
            Ventura, CA 93003</p>
          <p>866.555.4310<br />866.555.4315 <em>(24 hour support)</em></p>
        </div>
      </div>
    </div>
  </body>
</html>
